package com.meuclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class NinjaMenuScreen extends Screen {
    private static final int TEXT_OFF = 0xFFB4B4BE;
    private static final int COL_W = 120, GAP = 14, HEADER_H = 20, ROW_H = 18, TOP = 40;
    private static final int SWATCH = 12, SWATCH_GAP = 4;

    private boolean mouseHeld = true; // evita clique fantasma ao abrir
    private boolean rightHeld = true;
    private boolean showColors;       // painel de cores aberto?

    public NinjaMenuScreen() {
        super(Text.literal("NinjaClient"));
    }

    @Override
    public boolean shouldPause() { return false; }

    private static boolean in(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private List<Module> modulesOf(Category c) {
        List<Module> list = new ArrayList<>();
        for (Module m : MeuClient.modules.modules) if (m.category == c) list.add(m);
        return list;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long window = MinecraftClient.getInstance().getWindow().getHandle();
        boolean down = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean click = down && !mouseHeld;
        mouseHeld = down;

        boolean rightDown = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean rightClick = rightDown && !rightHeld;
        rightHeld = rightDown;

        Category[] cats = Category.values();
        int totalW = cats.length * COL_W + (cats.length - 1) * GAP;
        int x = (this.width - totalW) / 2;

        for (Category c : cats) {
            // cabecalho
            ctx.fill(x, TOP, x + COL_W, TOP + HEADER_H, Theme.header);
            ctx.drawText(textRenderer, c.label, x + 6, TOP + 6, 0xFFFFFFFF, false);

            // modulos
            int y = TOP + HEADER_H;
            for (Module m : modulesOf(c)) {
                boolean hov = in(mx, my, x, y, COL_W, ROW_H);
                String bind = m.bindLabel();
                boolean onBind = bind != null && in(mx, my, x + COL_W - 36, y, 36, ROW_H);
                if (hov && click) {
                    if (m.isSettings()) showColors = !showColors;
                    else if (onBind) m.onBindClick();
                    else m.toggle();
                }
                if (hov && rightClick) m.onRightClick();

                boolean on = m.isSettings() ? showColors : m.isEnabled();
                int bg = on ? (hov ? Theme.lighten(Theme.enabled, 24) : Theme.enabled)
                            : (hov ? Theme.lighten(Theme.background, 12) : Theme.background);
                ctx.fill(x, y, x + COL_W, y + ROW_H, bg);
                ctx.drawText(textRenderer, m.name + m.suffix(), x + 6, y + 5, on ? 0xFFFFFFFF : TEXT_OFF, false);
                if (bind != null) {
                    ctx.fill(x + COL_W - 34, y + 2, x + COL_W - 2, y + ROW_H - 2,
                            onBind ? Theme.lighten(Theme.header, 24) : Theme.header);
                    ctx.drawText(textRenderer, bind, x + COL_W - 31, y + 5, 0xFFFFFFFF, false);
                }
                y += ROW_H;
            }

            // painel de cores, logo abaixo da coluna Misc
            if (c == Category.MISC && showColors) {
                drawColorPanel(ctx, mx, my, click, x, y);
            }
            x += COL_W + GAP;
        }
    }

    /** Tres linhas de quadradinhos: fundo, opcao ativada e cabecalho. Clique escolhe a cor. */
    private void drawColorPanel(DrawContext ctx, int mx, int my, boolean click, int x, int y) {
        String[] labels = {"Fundo", "Ativado", "Cabecalho"};
        int[][] palettes = {Theme.BACKGROUNDS, Theme.ENABLED, Theme.HEADERS};
        int rowH = 10 + SWATCH + 6;
        int h = labels.length * rowH + 4;

        ctx.fill(x, y + 2, x + COL_W, y + 2 + h, Theme.background);

        int py = y + 6;
        for (int r = 0; r < labels.length; r++) {
            ctx.drawText(textRenderer, labels[r], x + 6, py, 0xFFFFFFFF, false);
            int sx = x + 6, sy = py + 11;
            for (int color : palettes[r]) {
                boolean hov = in(mx, my, sx, sy, SWATCH, SWATCH);
                int current = r == 0 ? Theme.background : r == 1 ? Theme.enabled : Theme.header;

                if (hov && click) {
                    if (r == 0) Theme.background = color;
                    else if (r == 1) Theme.enabled = color;
                    else Theme.header = color;
                    Config.markDirty();
                }
                // moldura branca na cor escolhida (ou com o mouse em cima)
                if (color == current || hov) {
                    ctx.fill(sx - 1, sy - 1, sx + SWATCH + 1, sy + SWATCH + 1, 0xFFFFFFFF);
                }
                ctx.fill(sx, sy, sx + SWATCH, sy + SWATCH, color | 0xFF000000);
                sx += SWATCH + SWATCH_GAP;
            }
            py += rowH;
        }
    }
}

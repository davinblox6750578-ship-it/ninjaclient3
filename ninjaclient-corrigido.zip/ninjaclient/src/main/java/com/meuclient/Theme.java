package com.meuclient;

/** Cores do menu. Mudam em tempo real pelo modulo "Cores" na coluna Misc. */
public final class Theme {
    private Theme() {}

    // opcoes de cada cor (a primeira de cada lista e a padrao)
    public static final int[] BACKGROUNDS = {
            0xF0202024, 0xF0000000, 0xF0101830, 0xF0281020, 0xF0102818, 0xF0301808, 0xF0383838};
    public static final int[] ENABLED = {
            0xFF1B2A8A, 0xFF8A1B1B, 0xFF1B8A2A, 0xFF8A1B7A, 0xFF8A6A1B, 0xFF1B7A8A, 0xFFB03060};
    public static final int[] HEADERS = {
            0xFF0F1A5C, 0xFF5C0F0F, 0xFF0F5C1A, 0xFF5C0F52, 0xFF5C460F, 0xFF0F525C, 0xFF111111};

    public static int background = BACKGROUNDS[0];
    public static int enabled = ENABLED[0];
    public static int header = HEADERS[0];

    /** Clareia uma cor (usado no efeito de mouse em cima). */
    public static int lighten(int color, int amount) {
        int a = color & 0xFF000000;
        int r = Math.min(255, ((color >> 16) & 0xFF) + amount);
        int g = Math.min(255, ((color >> 8) & 0xFF) + amount);
        int b = Math.min(255, (color & 0xFF) + amount);
        return a | (r << 16) | (g << 8) | b;
    }
}

package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;

/**
 * Caindo de uma altura (fallDistance > 1.5, o minimo do smash no vanilla):
 * mira no jogador ao alcance e ataca UMA vez com a clava.
 *
 * Por que antes nao atacava: a clava so era pega quando o alvo ja estava ao alcance,
 * e trocar de item ZERA a barra de cooldown (a clava leva ~1,5 s para carregar), entao
 * a barra nunca estava cheia na hora do golpe. Agora:
 *  - a clava e equipada CEDO, assim que um jogador chega a EQUIP_RANGE blocos
 *    (a barra carrega enquanto voce se aproxima / cai);
 *  - o alcance e medido ate a CAIXA do alvo (como o servidor faz), nao ate o centro;
 *  - NAO espera a barra de cooldown: ataca assim que o alvo entra no alcance;
 *  - nao ataca se o alvo estiver bloqueando com escudo (espera ele abaixar);
 *  - no maximo 1 ataque por queda e um intervalo minimo entre ataques.
 */
public class AutoMace extends Module {
    private static final double REACH = 3.0;         // olhos -> caixa do alvo
    private static final double EQUIP_RANGE = 12.0;  // pega a clava quando alguem chega perto
    private static final double MIN_FALL = 1.5;      // queda minima para o smash
    private static final int MIN_GAP_TICKS = 10;     // intervalo minimo entre ataques

    private boolean attackedThisFall;
    private int gap;

    public AutoMace() {
        super("AutoMace", Category.COMBAT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onDisable() {
        attackedThisFall = false;
        gap = 0;
    }

    @Override
    public void onTick() {
        if (gap > 0) gap--;
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || !mc.player.isAlive()) return;

        // pousou: libera um novo ataque na proxima queda
        if (mc.player.isOnGround()) attackedThisFall = false;

        // clava fora da mao: equipa cedo (trocar zera o cooldown, entao nao pode ser em cima da hora)
        if (!mc.player.getMainHandStack().isOf(Items.MACE)) {
            if (Combat.nearestPlayer(mc, EQUIP_RANGE) != null) selectMace();
            return;
        }

        if (mc.player.isOnGround() || attackedThisFall || gap > 0) return;
        if (mc.player.fallDistance <= MIN_FALL) return;

        PlayerEntity target = Combat.nearestPlayerInReach(mc, REACH);
        if (target == null) return;

        // escudo levantado: o smash seria bloqueado, entao espera ele abaixar
        if (target.isBlocking()) return;

        Combat.aimAt(mc, target, 180f);
        Combat.attack(mc, target);
        attackedThisFall = true;
        gap = MIN_GAP_TICKS;
    }

    private void selectMace() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.MACE)) {
                mc.player.getInventory().setSelectedSlot(i);
                return;
            }
        }
    }
}
